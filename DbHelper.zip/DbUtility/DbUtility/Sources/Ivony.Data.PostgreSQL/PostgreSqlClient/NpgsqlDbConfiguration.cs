﻿using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace Ivony.Data.PostgreSQL.PostgreSqlClient
{
  public class NpgsqlDbConfiguration : DbConfiguration { }
}
